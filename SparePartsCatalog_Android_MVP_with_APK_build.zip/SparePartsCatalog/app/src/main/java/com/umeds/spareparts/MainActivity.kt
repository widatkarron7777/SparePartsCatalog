package com.umeds.spareparts

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Ink = Color(0xFF101820)
private val Blue = Color(0xFF1C6E8C)
private val Paper = Color(0xFFF4F7F9)

private data class PhoneModel(
    val brand: String, val model: String, val code: String,
    val parts: List<PhonePart>
)
private data class PhonePart(
    val name: String, val category: String, val partNumber: String,
    val compatibility: String, val notes: String, val imageUrl: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SparePartsApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SparePartsApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("catalog", 0) }
    var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "") ?: "") }
    var search by remember { mutableStateOf("") }
    var selectedBrand by remember { mutableStateOf("Все бренды") }
    var models by remember { mutableStateOf(demoModels()) }
    var selectedModel by remember { mutableStateOf<PhoneModel?>(null) }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Демонстрационная база · ${models.size} моделей") }
    var showSettings by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val brands = listOf("Все бренды", "Samsung", "Redmi / Xiaomi", "iPhone", "realme", "Tecno", "Infinix")
    val filtered = models.filter {
        (selectedBrand == "Все бренды" || it.brand == selectedBrand) &&
        (search.isBlank() || listOf(it.brand, it.model, it.code).any { field -> field.contains(search.trim(), true) })
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Paper, surface = Color.White)) {
        Scaffold(containerColor = Paper, topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("SPARE PARTS", fontWeight = FontWeight.Black, color = Color.White)
                        Text("Каталог запчастей телефонов", style = MaterialTheme.typography.labelSmall, color = Color(0xFFB9DDE8))
                    }
                },
                actions = { TextButton(onClick = { showSettings = !showSettings }) { Text("БАЗА", color = Color.White) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
            )
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                if (showSettings) {
                    Card(Modifier.fillMaxWidth().padding(top = 12.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Подключение онлайн-каталога", fontWeight = FontWeight.Bold)
                            Text("Вставь HTTPS-ссылку на JSON-файл каталога. Пока ссылка не задана, приложение использует демонстрационные данные.", style = MaterialTheme.typography.bodySmall)
                            OutlinedTextField(endpoint, { endpoint = it }, modifier = Modifier.fillMaxWidth(), label = { Text("URL JSON-каталога") }, singleLine = true, placeholder = { Text("https://example.com/catalog.json") })
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(enabled = !loading, onClick = {
                                    prefs.edit().putString("endpoint", endpoint.trim()).apply()
                                    scope.launch {
                                        loading = true
                                        try {
                                            val downloaded = withContext(Dispatchers.IO) { loadRemote(endpoint.trim()) }
                                            models = downloaded
                                            selectedModel = null
                                            status = "Онлайн-база загружена · ${downloaded.size} моделей"
                                        } catch (e: Exception) {
                                            status = "Не удалось загрузить базу: ${e.message ?: "проверь URL и интернет"}"
                                        }
                                        loading = false
                                    }
                                }) { Icon(Icons.Default.CloudDownload, null); Spacer(Modifier.width(6.dp)); Text("Загрузить") }
                                OutlinedButton(onClick = { models = demoModels(); selectedModel = null; status = "Демонстрационная база · ${models.size} моделей" }) { Text("Демо-база") }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                if (selectedModel == null) {
                    Text("Найди нужный телефон", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Ink)
                    Text("По названию или коду модели", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Например, Galaxy A15 или SM-A155F") },
                        leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true,
                        shape = RoundedCornerShape(16.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        brands.take(4).forEach { brand ->
                            FilterChip(selected = selectedBrand == brand, onClick = { selectedBrand = brand }, label = { Text(brand, maxLines = 1, overflow = TextOverflow.Ellipsis) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        brands.drop(4).forEach { brand -> FilterChip(selected = selectedBrand == brand, onClick = { selectedBrand = brand }, label = { Text(brand) }) }
                    }
                    Text(status, style = MaterialTheme.typography.labelSmall, color = Color.Gray, modifier = Modifier.padding(vertical = 4.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                        items(filtered) { model -> ModelCard(model) { selectedModel = model } }
                        if (filtered.isEmpty()) item { Text("Модели не найдены. Проверь название или код.", modifier = Modifier.padding(20.dp), color = Color.Gray) }
                    }
                } else {
                    val model = selectedModel!!
                    TextButton(onClick = { selectedModel = null }) { Text("← К списку моделей") }
                    Text(model.model, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Ink)
                    Text("${model.brand} · ${model.code}", color = Color.Gray)
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SummaryTile("ДЕТАЛЕЙ", model.parts.size.toString(), Modifier.weight(1f))
                        SummaryTile("КАТЕГОРИЙ", model.parts.map { it.category }.distinct().size.toString(), Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(12.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                        items(model.parts) { part -> PartCard(part) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ModelCard(model: PhoneModel, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(58.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFE5F1F5)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Smartphone, null, tint = Blue, modifier = Modifier.size(30.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(model.model, fontWeight = FontWeight.Bold)
                Text(model.brand, style = MaterialTheme.typography.bodySmall, color = Blue)
                Text("Код: ${model.code}", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                Text("${model.parts.size} запчастей в каталоге", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
            }
            Text("›", style = MaterialTheme.typography.headlineMedium, color = Blue)
        }
    }
}

@Composable
private fun SummaryTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Blue)
        }
    }
}

@Composable
private fun PartCard(part: PhonePart) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
            Box(Modifier.size(96.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFE9EEF1)), contentAlignment = Alignment.Center) {
                if (part.imageUrl.isNotBlank()) {
                    AsyncImage(model = part.imageUrl, contentDescription = part.name, modifier = Modifier.fillMaxSize())
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Build, null, tint = Blue, modifier = Modifier.size(28.dp))
                        Text("Фото не задано", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    }
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(part.name, fontWeight = FontWeight.Bold)
                Text(part.category, color = Blue, style = MaterialTheme.typography.labelMedium)
                if (part.partNumber.isNotBlank()) Text("Артикул: ${part.partNumber}", style = MaterialTheme.typography.bodySmall)
                if (part.compatibility.isNotBlank()) Text("Совместимость: ${part.compatibility}", style = MaterialTheme.typography.bodySmall)
                if (part.notes.isNotBlank()) Text(part.notes, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
        }
    }
}

private fun loadRemote(urlText: String): List<PhoneModel> {
    require(urlText.startsWith("https://", true)) { "нужна HTTPS-ссылка на JSON" }
    val connection = (URL(urlText).openConnection() as HttpURLConnection).apply {
        connectTimeout = 12000; readTimeout = 12000; requestMethod = "GET"
        setRequestProperty("Accept", "application/json")
    }
    try {
        if (connection.responseCode !in 200..299) error("HTTP ${connection.responseCode}")
        val body = connection.inputStream.bufferedReader().use { it.readText() }
        val root = JSONObject(body)
        val array = root.optJSONArray("models") ?: JSONArray()
        return buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val partArray = item.optJSONArray("parts") ?: JSONArray()
                val parts = buildList {
                    for (j in 0 until partArray.length()) {
                        val p = partArray.optJSONObject(j) ?: continue
                        add(PhonePart(p.optString("name"), p.optString("category"), p.optString("partNumber"), p.optString("compatibility"), p.optString("notes"), p.optString("imageUrl")))
                    }
                }
                add(PhoneModel(item.optString("brand"), item.optString("model"), item.optString("code"), parts))
            }
        }.also { require(it.isNotEmpty()) { "в JSON нет моделей" } }
    } finally { connection.disconnect() }
}

private fun demoModels(): List<PhoneModel> {
    val commonParts = listOf(
        PhonePart("Дисплейный модуль", "Экран", "", "Проверить ревизию и разъём", "Демонстрационная запись: уточните совместимость перед заказом.", ""),
        PhonePart("Основная плата", "Электроника", "", "Только для точного кода модели", "Варианты памяти и региональные версии могут отличаться.", ""),
        PhonePart("Нижняя плата зарядки", "Платы и разъёмы", "", "Проверить форму платы и коннекторы", "", ""),
        PhonePart("Межплатный шлейф", "Шлейфы", "", "Для указанной модели", "", ""),
        PhonePart("Аккумулятор", "Питание", "", "Сверить маркировку батареи", "", ""),
        PhonePart("Основная камера", "Камеры", "", "Сверить количество камер и разъём", "", ""),
        PhonePart("Фронтальная камера", "Камеры", "", "Сверить маркировку", "", ""),
        PhonePart("Разговорный динамик", "Акустика", "", "Сверить конструкцию узла", "", ""),
        PhonePart("Полифонический динамик", "Акустика", "", "Сверить корпус модуля", "", ""),
        PhonePart("Шлейф кнопок питания и громкости", "Шлейфы", "", "Сверить расположение кнопок", "", ""),
        PhonePart("Задняя крышка", "Корпус", "", "Сверить цвет и региональную версию", "", ""),
        PhonePart("Вибромотор", "Компоненты", "", "Сверить тип контактов", "", "")
    )
    return listOf(
        PhoneModel("Samsung", "Galaxy A15", "SM-A155F", commonParts),
        PhoneModel("Redmi / Xiaomi", "Redmi 13C", "23100RN82L", commonParts),
        PhoneModel("iPhone", "iPhone 13", "A2633", commonParts),
        PhoneModel("realme", "realme C55", "RMX3710", commonParts),
        PhoneModel("Tecno", "Spark 20", "KJ5", commonParts),
        PhoneModel("Infinix", "Hot 40", "X6836", commonParts)
    )
}
